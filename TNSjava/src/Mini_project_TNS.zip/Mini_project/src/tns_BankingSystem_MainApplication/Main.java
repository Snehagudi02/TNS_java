package tns_BankingSystem_MainApplication;

import java.time.LocalDateTime;
import java.util.*;

// ---------------- ACCOUNT ----------------
class Account {
    private int accountID;
    private int customerID;
    private String type;
    private double balance;

    public Account(int accountID, int customerID, String type, double balance) {
        this.accountID = accountID;
        this.customerID = customerID;
        this.type = type;
        this.balance = balance;
    }

    public int getAccountID() { return accountID; }
    public int getCustomerID() { return customerID; }
    public String getType() { return type; }
    public double getBalance() { return balance; }

    public void setType(String type) { this.type = type; }
    public void setBalance(double balance) { this.balance = balance; }
}

// ---------------- BENEFICIARY ----------------
class Beneficiary {
    private int beneficiaryID;                                        // class creation 
    private int customerID;
    private String name;                             // these are  variables  
    private String accountNumber;
    private String bankDetails;

    public Beneficiary(int beneficiaryID, int customerID, String name, String accountNumber, String bankDetails) {   /// constructor 
        this.beneficiaryID = beneficiaryID;
        this.customerID = customerID;
        this.name = name;
        this.accountNumber = accountNumber;
        this.bankDetails = bankDetails;
    }

    public int getBeneficiaryID() { return beneficiaryID; }
    public int getCustomerID() { return customerID; }
    public String getName() { return name; }
    public String getAccountNumber() { return accountNumber; }
    public String getBankDetails() { return bankDetails; }

    public void setName(String name) { this.name = name; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setBankDetails(String bankDetails) { this.bankDetails = bankDetails; }
}

// ---------------- CUSTOMER ----------------
class Customer {
    private int customerID;
    private String name;
    private String address;
    private String contact;

    public Customer(int customerID, String name, String address, String contact) {
        this.customerID = customerID;
        this.name = name;
        this.address = address;
        this.contact = contact;
    }

    public int getCustomerID() { return customerID; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getContact() { return contact; }

    public void setName(String name) { this.name = name; }
    public void setAddress(String address) { this.address = address; }
    public void setContact(String contact) { this.contact = contact; }
}

// ---------------- TRANSACTION ----------------
class Transaction {
    private static int idCounter = 1;
    private int transactionID;
    private int accountID;
    private String type;
    private double amount;
    private LocalDateTime timestamp;

    public Transaction(int accountID, String type, double amount) {
        this.transactionID = idCounter++;
        this.accountID = accountID;
        this.type = type;
        this.amount = amount;
        this.timestamp = LocalDateTime.now();
    }

    public int getTransactionID() { return transactionID; }
    public int getAccountID() { return accountID; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public LocalDateTime getTimestamp() { return timestamp; }
}

// ---------------- SERVICE INTERFACE ----------------
interface BankingService {
    void addCustomer(Customer customer);
    void addAccount(Account account);
    void addTransaction(Transaction transaction);
    void addBeneficiary(Beneficiary beneficiary);

    Customer findCustomerById(int id);
    Account findAccountById(int id);
    Transaction findTransactionById(int id);
    Beneficiary findBeneficiaryById(int id);

    Collection<Account> getAllAccounts();
    Collection<Customer> getAllCustomers();
    Collection<Transaction> getAllTransactions();
    Collection<Beneficiary> getAllBeneficiaries();

    List<Account> getAccountsByCustomerId(int customerId);
    List<Transaction> getTransactionsByAccountId(int accountId);
    List<Beneficiary> getBeneficiariesByCustomerId(int customerId);
}

// ---------------- SERVICE IMPLEMENTATION ----------------
class BankingServiceImpl implements BankingService {

    private Map<Integer, Customer> customers = new HashMap<>();
    private Map<Integer, Account> accounts = new HashMap<>();
    private Map<Integer, Transaction> transactions = new HashMap<>();
    private Map<Integer, Beneficiary> beneficiaries = new HashMap<>();

    public void addCustomer(Customer customer) {
        customers.put(customer.getCustomerID(), customer);
    }

    public void addAccount(Account account) {
        accounts.put(account.getAccountID(), account);
    }

    public void addTransaction(Transaction transaction) {
        transactions.put(transaction.getTransactionID(), transaction);

        Account acc = accounts.get(transaction.getAccountID());
        if (acc != null) {
            if (transaction.getType().equalsIgnoreCase("Deposit"))
                acc.setBalance(acc.getBalance() + transaction.getAmount());
            else if (transaction.getType().equalsIgnoreCase("Withdrawal"))
                acc.setBalance(acc.getBalance() - transaction.getAmount());
        }
    }

    public void addBeneficiary(Beneficiary beneficiary) {
        beneficiaries.put(beneficiary.getBeneficiaryID(), beneficiary);
    }

    public Customer findCustomerById(int id) { return customers.get(id); }
    public Account findAccountById(int id) { return accounts.get(id); }
    public Transaction findTransactionById(int id) { return transactions.get(id); }
    public Beneficiary findBeneficiaryById(int id) { return beneficiaries.get(id); }

    public List<Account> getAccountsByCustomerId(int customerId) {
        List<Account> result = new ArrayList<>();
        for (Account a : accounts.values())
            if (a.getCustomerID() == customerId) result.add(a);
        return result;
    }

    public List<Transaction> getTransactionsByAccountId(int accountId) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction t : transactions.values())
            if (t.getAccountID() == accountId) result.add(t);
        return result;
    }

    public List<Beneficiary> getBeneficiariesByCustomerId(int customerId) {
        List<Beneficiary> result = new ArrayList<>();
        for (Beneficiary b : beneficiaries.values())
            if (b.getCustomerID() == customerId) result.add(b);
        return result;
    }

    public Collection<Account> getAllAccounts() { return accounts.values(); }
    public Collection<Customer> getAllCustomers() { return customers.values(); }
    public Collection<Transaction> getAllTransactions() { return transactions.values(); }
    public Collection<Beneficiary> getAllBeneficiaries() { return beneficiaries.values(); }
}

// ---------------- MAIN APPLICATION ----------------
public class Main {

    public static void main(String[] args) {

        BankingService bankingService = new BankingServiceImpl();
        Scanner sc = new Scanner(System.in);
        int ch;

        do {
            System.out.println("\nBanking System");
            System.out.println("1. Add Customers");
            System.out.println("2. Add Accounts");
            System.out.println("3. Add Beneficiary");
            System.out.println("4. Add Transaction");
            System.out.println("5. Find Customer by Id ");
            System.out.println("6. List all Accounts of specific Customer");
            System.out.println("7. List all transactions of specific Account");
            System.out.println("8. List all beneficiaries of specific customer");
            System.out.println("9. Exit");
            System.out.print("Enter your choice : ");
            ch = sc.nextInt();

            switch (ch) {

                case 1:
                    System.out.print("Customer Id : ");
                    int customerID = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Name : ");
                    String name = sc.nextLine();
                    System.out.print("Address : ");
                    String address = sc.nextLine();
                    System.out.print("Contact No. : ");
                    String contact = sc.nextLine();
                    bankingService.addCustomer(new Customer(customerID, name, address, contact));
                    break;

                case 2:
                    System.out.print("Account Id : ");
                    int accountID = sc.nextInt();
                    System.out.print("Customer Id : ");
                    customerID = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Account Type : ");
                    String type = sc.nextLine();
                    System.out.print("Balance : ");
                    double balance = sc.nextDouble();
                    bankingService.addAccount(new Account(accountID, customerID, type, balance));
                    break;

                case 3:
                    System.out.print("Customer Id : ");
                    customerID = sc.nextInt();
                    System.out.print("Benefiary Id : ");
                    int beneficiaryID = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Beneficiary Name : ");
                    name = sc.nextLine();
                    System.out.print("Account No. : ");
                    String accountNumber = sc.nextLine();
                    System.out.print("Bank details : ");
                    String bankDetails = sc.nextLine();
                    bankingService.addBeneficiary(
                            new Beneficiary(beneficiaryID, customerID, name, accountNumber, bankDetails));
                    break;

                case 4:
                    System.out.print("Account Id : ");
                    accountID = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Type (Deposit/Withdrawal): ");
                    type = sc.nextLine();
                    System.out.print("Amount : ");
                    double amount = sc.nextDouble();
                    bankingService.addTransaction(new Transaction(accountID, type, amount));
                    break;

                case 5:
                    for (Customer customer : bankingService.getAllCustomers())
                        System.out.println("Customer ID: " + customer.getCustomerID() + ", Name: " + customer.getName());
                    System.out.print("Customer Id : ");
                    customerID = sc.nextInt();
                    Customer foundCustomer = bankingService.findCustomerById(customerID);
                    if (foundCustomer != null)
                        System.out.println("Customer: " + foundCustomer.getName());
                    else
                        System.out.println("Customer not found");
                    break;

                case 6:
                    System.out.print("Customer Id : ");
                    customerID = sc.nextInt();
                    List<Account> customerAccounts = bankingService.getAccountsByCustomerId(customerID);
                    for (Account account : customerAccounts)
                        System.out.println("Account ID: " + account.getAccountID() +
                                ", Balance: " + account.getBalance());
                    break;

                case 7:
                    System.out.print("Account Id : ");
                    accountID = sc.nextInt();
                    List<Transaction> accountTransactions = bankingService.getTransactionsByAccountId(accountID);
                    for (Transaction transaction : accountTransactions)
                        System.out.println("Transaction ID: " + transaction.getTransactionID() +
                                ", Type: " + transaction.getType() +
                                ", Amount: " + transaction.getAmount() +
                                ", Timestamp: " + transaction.getTimestamp());
                    break;

                case 8:
                    System.out.print("Customer Id : ");
                    customerID = sc.nextInt();
                    List<Beneficiary> customerBeneficiaries =
                            bankingService.getBeneficiariesByCustomerId(customerID);
                    for (Beneficiary b : customerBeneficiaries)
                        System.out.println("Beneficiary ID: " + b.getBeneficiaryID() +
                                ", Name: " + b.getName());
                    break;

                case 9:
                    System.out.println("Thank you!");
                    break;

                default:
                    System.out.println("Invalid Choice");
            }

        } while (ch != 9);
    }
}
